# Face Recognition Attendance System with Django and OpenCV

A modern, AI-powered attendance management system that uses face recognition technology to automate student attendance tracking. Built with Django and OpenCV, this system provides real-time face detection and recognition capabilities for educational institutions.

## 🚀 Features

### Core Functionality
- **Real-time Face Recognition**: Automatic student identification using webcam
- **Attendance Tracking**: Automated check-in/check-out with timestamp recording
- **Student Management**: Complete CRUD operations for student records
- **Department Organization**: Organize students by departments and classes
- **Face Registration**: Easy face capture and encoding for new students

### Advanced Features
- **Live Video Stream**: Real-time attendance marking with visual feedback
- **Face Search**: Search students by uploading their photo
- **Attendance Analytics**: View attendance statistics and reports
- **Confidence Scoring**: Face matching with confidence percentage
- **Timezone Support**: Configured for China Standard Time (CST)

### Technical Features
- **Modern UI**: Responsive design with Bootstrap 5 and custom gradients
- **Database Optimization**: Efficient queries with proper indexing
- **Image Processing**: Automatic face detection and encoding
- **Security**: CSRF protection and secure file uploads
- **Error Handling**: Comprehensive error management and user feedback

## 🛠️ Technology Stack

### Backend
- **Django 4.2.7**: Python web framework
- **SQLite**: Database (development)
- **face-recognition 1.3.0**: Face recognition library
- **OpenCV 4.8.1**: Computer vision and image processing
- **NumPy 1.24.3**: Numerical computing

### Frontend
- **Bootstrap 5**: Modern CSS framework
- **Bootstrap Icons**: Icon library
- **Inter Font**: Modern typography
- **Custom CSS**: Gradient backgrounds and animations

### Development Tools
- **Django Crispy Forms**: Form styling with Bootstrap 5
- **Pillow 10.1.0**: Image processing
- **pytz**: Timezone handling

## 📋 Requirements

### System Requirements
- Python 3.8+
- Webcam (for face recognition)
- 4GB+ RAM recommended
- Modern web browser

### Python Dependencies
```
Django==4.2.7
opencv-python==4.8.1.78
face-recognition==1.3.0
numpy==1.24.3
Pillow==10.1.0
django-crispy-forms==2.1
crispy-bootstrap5==0.7
```

## 🔧 Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd face_attendance_system
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Database Setup
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Create Superuser (Admin)
```bash
python manage.py createsuperuser
```

### 6. Run Development Server
```bash
python manage.py runserver
```

### 7. Access the Application
- Main Application: http://127.0.0.1:8000/
- Admin Panel: http://127.0.0.1:8000/admin/

## 📁 Project Structure

```
face_attendance_system/
├── face_attendance_system/     # Django project settings
│   ├── settings.py           # Configuration
│   ├── urls.py              # URL routing
│   └── wsgi.py              # WSGI configuration
├── students/                  # Main application
│   ├── models.py             # Database models
│   ├── views.py              # View logic
│   ├── urls.py               # App URL patterns
│   ├── forms.py              # Django forms
│   ├── utils.py              # Utility functions
│   └── video_stream.py       # Face recognition logic
├── templates/                # HTML templates
│   ├── base.html             # Base template
│   ├── dashboard.html        # Dashboard view
│   └── students/             # Student-specific templates
├── media/                    # Uploaded files
│   ├── student_photos/       # Student face photos
│   ├── search_photos/        # Search query photos
│   └── temp/                 # Temporary files
├── static/                   # Static files (CSS, JS)
├── db.sqlite3               # SQLite database
├── manage.py               # Django management
└── requirements.txt        # Python dependencies
```

## 🎯 Core Models

### Student Model
- **Personal Info**: Name, ID, email, phone, date of birth, address
- **Academic Info**: Department, major, year, class
- **Face Data**: Photo, face encoding, registration status
- **Status**: Active/inactive flag

### Department Model
- **Basic Info**: Name, code, description
- **Relationships**: One-to-many with students

### AttendanceRecord Model
- **Attendance Data**: Student, date, time-in, time-out
- **Status**: Present, absent, late
- **Metadata**: Confidence score, remarks

### FaceSearchLog Model
- **Search Data**: Search photo, matched student, confidence
- **Status**: Success, no match, error

## 🔍 Face Recognition Process

### 1. Face Registration
1. Student photo is captured via webcam or uploaded
2. Face detection using `face_recognition` library
3. Face encoding generation (128-dimensional vector)
4. Encoding stored in database as binary data

### 2. Real-time Recognition
1. Webcam captures video frames
2. Face detection in each frame
3. Face encoding generation for detected faces
4. Comparison with known student encodings
5. Attendance marking for recognized students
6. Visual feedback with name and confidence score

### 3. Face Search
1. Upload photo for search
2. Face detection and encoding
3. Comparison with all registered students
4. Return best match with confidence score

## 🎨 User Interface

### Dashboard
- Statistics cards with gradient backgrounds
- Recent students and attendance records
- Quick action buttons
- Responsive design for all devices

### Student Management
- Student list with search functionality
- Create/edit forms with validation
- Face capture interface
- Detailed student profiles with attendance history

### Attendance System
- Real-time video feed
- Live face recognition overlay
- Automatic attendance marking
- Visual status indicators

## ⚙️ Configuration

### Settings Highlights
- **Timezone**: Asia/Shanghai (China Standard Time)
- **Media Files**: Student photos and search images
- **Database**: SQLite (easily configurable for PostgreSQL/MySQL)
- **Static Files**: Bootstrap 5 CDN integration
- **Security**: CSRF protection enabled

### Face Recognition Parameters
- **Tolerance**: 0.6 (60% similarity threshold)
- **Detection Scale**: 0.25x for performance
- **Confidence Display**: Percentage-based scoring
- **Attendance Logic**: One check-in per day per student

## 🔒 Security Considerations

- CSRF protection for all forms
- Secure file upload handling
- Input validation and sanitization
- SQL injection prevention (Django ORM)
- XSS protection (Django templates)

## 🚀 Performance Optimization

- Face detection at reduced resolution (0.25x)
- Database indexing on frequently queried fields
- Efficient face encoding storage (binary format)
- Lazy loading of student data
- Optimized template rendering

## 📊 Usage Statistics

The dashboard provides real-time statistics:
- Total registered students
- Number of faces registered
- Department count
- Today's attendance count
- Recent activity feeds

## 🔧 Troubleshooting

### Common Issues

1. **Camera Not Working**
   - Check webcam permissions
   - Verify OpenCV installation
   - Test with other applications

2. **Face Recognition Accuracy**
   - Ensure good lighting conditions
   - Clear, front-facing photos
   - Multiple angles for better recognition

3. **Database Issues**
   - Run migrations: `python manage.py migrate`
   - Check SQLite file permissions
   - Verify model relationships

4. **Performance Issues**
   - Reduce video resolution if needed
   - Optimize face detection parameters
   - Consider upgrading hardware

## 🔄 Future Enhancements

### Planned Features
- **Mobile App**: React Native or Flutter application
- **API Endpoints**: RESTful API for third-party integration
- **Advanced Analytics**: Detailed attendance reports and trends
- **Multi-campus Support**: Support for multiple locations
- **Email Notifications**: Automated attendance reports
- **Backup System**: Automated database backups

### Technical Improvements
- **Redis Integration**: Caching for better performance
- **PostgreSQL**: Production-ready database
- **Docker Support**: Containerized deployment
- **Cloud Storage**: AWS S3 or similar for media files
- **Machine Learning**: Custom face recognition models

## 📞 Support

For issues, questions, or contributions:
1. Check the troubleshooting section
2. Review the GitHub issues
3. Create a new issue with detailed information
4. Include system specifications and error logs

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🙏 Acknowledgments

- Django framework for the robust backend
- face-recognition library for AI capabilities
- OpenCV for computer vision functionality
- Bootstrap for modern UI components
- Contributors and testers

---

**Made with ❤️ for educational institutions**